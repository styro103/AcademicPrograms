/*ECE 264
  Lab 01
  Problem 03
  Shaun Mbateng
  This program takes an array, prints it, sorts it, and searches for an element all using multiple methods.
*/

#include <stdio.h>
#include <iostream>
using namespace std;

void printArray(double arr[], int size);
int linearSearch(double arr[], int size, double valueToSearchFor);
void copyArray(double & destination[], double source[], int size);
void bubbleSort(double & arr[], int size);
int binarySearch(double arr[], int size, double valueToSearchFor);

int main()
{
	double first[100]; //First Array
	double second[100]; //
	double value;
	int index;
	int i;

	for (i = 0; i < 100; i++)
	{
		cout<<"Enter element number "<<(i+1)<<":"<<endl;
		cin>>first[i];
		if (first[i]>999)
			break;
	}

	printArray(first, i);

	cout<<"Enter 1st value to search for:"<<endl;
	cin>>value;

	index = linearSearch(first, i, value);

	if (index == -1)
		cout<<"The value is not in the array."<<endl;
	else
		cout<<"The value is element number "<<index+1<<" in the array."<<endl;

	copyArray(second, first, i);
	bubbleSort(second, i);

	cout<<"Enter 2nd value to search for:"<<endl;
	cin>>value;

	index = binarySearch(second, i, value);

	if (index == -1)
		cout<<"The value is not in the array."<<endl;
	else
		cout<<"The value is element number "<<index+1<<" in the array."<<endl;

	return 0;
}

void printArray(double arr[], int size)
{
	for (int j = 0; j <= size; j++)
	{	
		cout<<arr[j];
		if ((j+1) % 3 == 0)
			cout<<""<<endl;
	}
}

int linearSearch(double arr[], int size, double valueToSearchFor)
{
	bool Found = false;
	int j = 0;
	
	while (j <= size && arr[j] != valueToSearchFor)
	{
		if (arr[j] == valueToSearchFor)
		{
			Found = true;
		}
	}

	if (Found = false)
	{
		j = -1;
	}
	
	return j;
}

void copyArray(double & destination[], double source[], int size)
{
	for (int j = 0; j <= size; j++)
		destination[j] = source[j];
}

void bubbleSort(double & arr[], int size)
{
	int t = 0;
	int temp;

	while (t <= size)
	{
		for (int j = 1; j <= size; j++)
		{
			if (arr[j-1] > arr[j])
			{
				temp = arr[j];
				arr[j] = arr[j-1];
				arr[j-1] = temp;
			}
		}

		t++;
	}
}

int binarySearch(double arr[], int size, double valueToSearchFor)
{
	int top = 0;
	int bottom = size;
	int mid;
	int ind = -1;

	while (top <= bottom)
	{
		 mid = (top+bottom)/2; 
		
		if(arr[mid]==valueToSearchFor)
		{
			ind = mid; 
			break;
		}
		else if (arr[mid]>valueToSearchFor)
		{
			bottom=mid-1;
		}
		else
		{
			top=mid+1;
		}
	}

	return ind;
		
}