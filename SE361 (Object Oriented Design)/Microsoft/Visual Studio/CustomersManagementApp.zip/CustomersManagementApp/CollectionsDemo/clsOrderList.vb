﻿Public Class clsOrderList
    Dim orders As New Collection

    Public Sub addNewOrder(ByVal item As String, ByVal unitprice As Decimal, ByVal totalprice As Decimal, ByVal quantity As Integer, ByVal shippingaddress As String)
        'Due to Time Restraints I Couldn't Finish This, But I UnderStand I would Have to Create an Order GUI and Call It Whenever I Wanted to Create an Order
End Class
